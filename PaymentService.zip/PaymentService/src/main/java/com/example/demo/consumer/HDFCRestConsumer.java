package com.example.demo.consumer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class HDFCRestConsumer {

    @Autowired
    private DiscoveryClient discoveryClient;

    public String getHdfcData() {

        List<ServiceInstance> instances =
                discoveryClient.getInstances("HDFC-PAYMENT");

        if(instances.isEmpty()) {
            return "HDFC Service Not Available";
        }

        ServiceInstance instance = instances.get(0);

        String url = instance.getUri() + "/hdfc/payment";

        RestTemplate restTemplate = new RestTemplate();

        return restTemplate.getForObject(url, String.class);
    }
}
package com.example.demo.consumer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class CartRestConsumer {
	
	@Autowired
	private DiscoveryClient discoveryClient;
	
	public String getCartData(){
		//Find cart service instance from eureka 
		List<ServiceInstance> instance = discoveryClient.getInstances("CART-SERVICE");
		
		if(instance==null || instance.isEmpty()) return "Car Service not available right now";
		
		//pick first available one
		ServiceInstance instances = instance.get(0);
		//Create url to call cart service
		String url = instances.getUri() + "/cart/getData";
		
		RestTemplate restTemplate = new RestTemplate();
		return restTemplate.getForObject(url, String.class);
	}
}

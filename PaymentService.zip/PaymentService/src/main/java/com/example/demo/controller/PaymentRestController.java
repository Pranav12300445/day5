package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.consumer.CartRestConsumer;
import com.example.demo.consumer.HDFCRestConsumer;

@RestController
public class PaymentRestController {

	@Autowired
	private CartRestConsumer cartRestConsumer;
	
	@Autowired
	private HDFCRestConsumer hdfcRestConsumer;
	
	@GetMapping("/payment/data")
	public String getPaymentData(){
		return hdfcRestConsumer.getHdfcData() +  " From Payment Service " +cartRestConsumer.getCartData();
	}
}

package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HDFCController {

    @GetMapping("/hdfc/payment")
    public String payment() {
        return "Payment using HDFC";
    }
}
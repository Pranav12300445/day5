package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class HdfcPaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HdfcPaymentApplication.class, args);
	}

}
